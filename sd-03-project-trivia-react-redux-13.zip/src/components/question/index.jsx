import React from 'react';
import './style.css';

function Question() {
  return (
    <div>
      <div className="uk-child-width-1-3@m uk-grid-small uk-grid-match">
        <div>
          <div className="uk-card uk-card-default uk-card-body border">
            <h3 className="uk-card-title">Titulo</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Question;
