import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import Navbar from '../../components/Navbar'

class Feedback extends Component {
  render() {
    const { assertions, score } = '?';
    const answerFeedback = assertions < 3 ? 'Podia ser melhor...' : 'Mandou bem!';
    return (
      <div className="flexbox">
        <header><Navbar /></header>
        <h2 data-testid="feedback-text">{answerFeedback}</h2>
        <p data-testid="feedback-total-question">{`Você acertou ${assertions || 0} questões!`}</p>
        <p data-testid="feedback-total-score">{`Um total de ${score || 0} pontos`}</p>
        <section>
          <div>
            <Link
              data-testid="btn-ranking"
              to="/ranking"
            >
              VER RANKING
            </Link>
          </div>
          <div>
            <Link
              data-testid="btn-play-again"
              to="/"
            >
              JOGAR NOVAMENTE
            </Link>
          </div>
        </section>
      </div>
    );
  }
}

export default Feedback;
