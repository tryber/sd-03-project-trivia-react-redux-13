import React from 'react';
import './style.css';

function Login() {
  return (
    <div className="flexbox" data-testid="settings-title">
      Teste
    </div>
  );
}

export default Login;
