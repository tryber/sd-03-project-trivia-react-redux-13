import React from 'react';
import './style.css';

function Login() {
  return (
    <div className="flexbox">
      Teste
    </div>
  );
}

export default Login;
